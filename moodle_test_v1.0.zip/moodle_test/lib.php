<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Test Moodle block common configuration and helper functions
 *
 * @package    block_moodle_test
 * @copyright  2022
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir.'/completionlib.php');

/**
 * Default number of cells per row in wrap mode.
 */
const DEFAULT_COMPLETIONPROGRESS_WRAPAFTER = 16;

/**
 * Default presentation mode for long bars: squeeze, scroll, or wrap.
 */
const DEFAULT_COMPLETIONPROGRESS_LONGBARS = 'squeeze';

/**
 * Default course name (long/short) to show on Dashboard pages.
 */
const DEFAULT_COMPLETIONPROGRESS_COURSENAMETOSHOW = 'shortname';

/**
 * Default display of inactive students on the overview page.
 */
const DEFAULT_COMPLETIONPROGRESS_SHOWINACTIVE = 0;

/**
 * Default display of student 'last in course' time on overview page.
 */
const DEFAULT_COMPLETIONPROGRESS_SHOWLASTINCOURSE = 1;

/**
 * Default forcing the display of status icons in bar cells.
 */
const DEFAULT_COMPLETIONPROGRESS_FORCEICONSINBAR = 0;

/**
 * Default display of status icons in bar cells.
 */
const DEFAULT_COMPLETIONPROGRESS_PROGRESSBARICONS = 0;

/**
 * Default cell sort order mode: orderbytime or orderbycourse.
 */
const DEFAULT_COMPLETIONPROGRESS_ORDERBY = 'orderbytime';

/**
 * Default display of progress percentage in block.
 */
const DEFAULT_COMPLETIONPROGRESS_SHOWPERCENTAGE = 0;

/**
 * Default choice of activites included: activitycompletion or selectedactivities.
 */
const DEFAULT_COMPLETIONPROGRESS_ACTIVITIESINCLUDED = 'activitycompletion';

/**
 * Finds submissions for a user in a course
 *
 * @param int    $courseid ID of the course
 * @param int    $userid   ID of user in the course, or 0 for all
 * @return array Course module IDs submissions
 */
function block_moodle_test_submissions($courseid, $userid = 0) {
    global $DB, $CFG;

    require_once($CFG->dirroot . '/mod/quiz/lib.php');

    $submissions = array();
    return $submissions;
}
/**
 * Returns the activities with completion set in current course
 *
 * @param int    $courseid   ID of the course
 * @param int    $config     The block instance configuration
 * @param string $forceorder An override for the course order setting
 * @return array Activities with completion settings in the course
 */
function block_moodle_test_get_activities($courseid, $config = null, $forceorder = null) {
    global $DB;
    $modinfo = get_fast_modinfo($courseid, -1);
    $sections = $modinfo->get_sections();
    $activities = array();
    foreach ($modinfo->instances as $module => $instances) {
        $modulename = get_string('pluginname', $module);
        foreach ($instances as $cm) {
            if (
                $cm->completion != COMPLETION_TRACKING_NONE && (
                    $config == null || (
                        !isset($config->activitiesincluded) || (
                            $config->activitiesincluded != 'selectedactivities' ||
                                !empty($config->selectactivities) &&
                                in_array($module.'-'.$cm->instance, $config->selectactivities))))
            ) {
                $params = array('id' => $cm->instance);
                $created = $DB->get_record($module, $params, 'timemodified');
                $activities[] = array (
                    'type'       => $module,
                    'modulename' => $modulename,
                    'id'         => $cm->id,
                    'instance'   => $cm->instance,
                    'name'       => format_string($cm->name),
                    'timemodified' => $created->timemodified,
                    'expected'   => $cm->completionexpected,
                    'section'    => $cm->sectionnum,
                    'position'   => array_search($cm->id, $sections[$cm->sectionnum]),
                    'url'        => method_exists($cm->url, 'out') ? $cm->url->out() : '',
                    'context'    => $cm->context,
                    'icon'       => $cm->get_icon_url(),
                    'available'  => $cm->available,
                );
            }
        }
    }

    // Sort by first value in each element, which is time due.
    if ($forceorder == 'orderbycourse' || ($config && $config->orderby == 'orderbycourse')) {
        usort($activities, 'block_moodle_test_compare_events');
    } else {
        usort($activities, 'block_moodle_test_compare_times');
    }

    return $activities;
}

/**
 * Used to compare two activities/resources based on order on course page
 *
 * @param array $a array of event information
 * @param array $b array of event information
 * @return <0, 0 or >0 depending on order of activities/resources on course page
 */
function block_moodle_test_compare_events($a, $b) {
    if ($a['section'] != $b['section']) {
        return $a['section'] - $b['section'];
    } else {
        return $a['position'] - $b['position'];
    }
}

/**
 * Used to compare two activities/resources based their expected completion times
 *
 * @param array $a array of event information
 * @param array $b array of event information
 * @return <0, 0 or >0 depending on time then order of activities/resources
 */
function block_moodle_test_compare_times($a, $b) {
    if (
        $a['expected'] != 0 &&
        $b['expected'] != 0 &&
        $a['expected'] != $b['expected']
    ) {
        return $a['expected'] - $b['expected'];
    } else if ($a['expected'] != 0 && $b['expected'] == 0) {
        return -1;
    } else if ($a['expected'] == 0 && $b['expected'] != 0) {
        return 1;
    } else {
        return block_moodle_test_compare_events($a, $b);
    }
}

/**
 * Filters activities that a user cannot see due to grouping constraints
 *
 * @param array  $activities The possible activities that can occur for modules
 * @param array  $userid The user's id
 * @param string $courseid the course for filtering visibility
 * @param array  $exclusions Assignment exemptions for students in the course
 * @return array The array with restricted activities removed
 */
function block_moodle_test_filter_visibility($activities, $userid, $courseid, $exclusions) {
    global $CFG;
    $filteredactivities = array();
    $modinfo = get_fast_modinfo($courseid, $userid);
    $coursecontext = CONTEXT_COURSE::instance($courseid);

    // Keep only activities that are visible.
    foreach ($activities as $activity) {

        $coursemodule = $modinfo->cms[$activity['id']];

        // Check visibility in course.
        if (!$coursemodule->visible && !has_capability('moodle/course:viewhiddenactivities', $coursecontext, $userid)) {
            continue;
        }

        // Check availability, allowing for visible, but not accessible items.
        if (!empty($CFG->enableavailability)) {
            if (has_capability('moodle/course:viewhiddenactivities', $coursecontext, $userid)) {
                $activity['available'] = true;
            } else {
                if (isset($coursemodule->available) && !$coursemodule->available && empty($coursemodule->availableinfo)) {
                    continue;
                }
                $activity['available'] = $coursemodule->available;
            }
        }

        // Check for exclusions.
        if (in_array($activity['type'].'-'.$activity['instance'].'-'.$userid, $exclusions)) {
            continue;
        }

        // Save the visible event.
        $filteredactivities[] = $activity;
    }
    return $filteredactivities;
}

/**
 * Checked if a user has completed an activity/resource
 *
 * @param array $activities  The activities with completion in the course
 * @param int   $userid      The user's id
 * @param int   $course      The course instance
 * @param array $submissions Submissions information, keyed by 'userid-cmid'
 * @return array   an describing the user's attempts based on module+instance identifiers
 */
function block_moodle_test_completions($activities, $userid, $course, $submissions) {
    $completions = array();
    $completioninfo = new completion_info($course);
    $cm = new stdClass();

    foreach ($activities as $activity) {
        $cm->id = $activity['id'];
        $completion = $completioninfo->get_data($cm, true, $userid);
        $submission = $submissions[$userid . '-' . $cm->id] ?? null;

        if ($completion->completionstate == COMPLETION_INCOMPLETE && $submission) {
            $completions[$cm->id] = 'submitted';
        } else if ($completion->completionstate == COMPLETION_COMPLETE_FAIL && $submission
                && !$submission->graded) {
            $completions[$cm->id] = 'submitted';
        } else {
            $completions[$cm->id] = $completion->completionstate;
        }
    }

    return $completions;
}
function block_moodle_test_div($activities, $completions, $config, $userid, $courseid, $instance, $simple = false) {
    global $OUTPUT, $CFG, $USER;
    $content = '';
    $now = time();
    $usingrtl = right_to_left();
    $numactivities = count($activities);
    $dateformat = "%d %b %Y";
    $content = "";
    $cellcontent = "";
    foreach ($activities as $activity) {
        $complete = $completions[$activity['id']];
        $content = "";
        $status = "";
        // A cell in the test block.
        if ($complete === 'submitted') {
            $status = "Submitted not completed";

        } else if ($complete == COMPLETION_COMPLETE || $complete == COMPLETION_COMPLETE_PASS) {
            $status = "completed";

        } else if (
            $complete == COMPLETION_COMPLETE_FAIL ||
            (!isset($config->orderby) || $config->orderby == 'orderbytime') &&
            (isset($activity['expected']) && $activity['expected'] > 0 && $activity['expected'] < $now)
        ) {
            $status = 'Not Completed';

        } else {
            $status = 'Not Completed';
        }

        if ($status != "completed") {
            $status = "";
        } else {
            $status = '  -  '.$status;
        }
        $cellcontent .= HTML_WRITER::link('../mod/'.$activity['type'].'/view.php?id='.$activity['id'],
        $activity['id'] .'  -  '. $activity['name']."  -  " .userdate($activity['timemodified'],
        $dateformat, $CFG->timezone).$status."</br></br>");
        $content .= $cellcontent;

    }
    return $content;
}


/**
 * Checks whether the given page is the Dashboard or Site home page.
 *
 * @param moodle_page $page the page to check, or the current page if not passed.
 * @return boolean True when on the Dashboard or Site home page.
 */
function block_moodle_test_on_site_page($page = null) {
    global $PAGE;

    $page = $page ?? $PAGE;
    if (empty($page)) {
        return false;   // Might be an asynchronous course copy.
    }

    $pagetypepatterns = matching_page_type_patterns_from_pattern($page->pagetype);
    return in_array('my-*', $pagetypepatterns) || in_array('site-*', $pagetypepatterns);
}

/**
 * Finds gradebook exclusions for students in a course
 *
 * @param int $courseid The ID of the course containing grade items
 * @param int $userid   The ID of the user whos grade items are being retrieved
 * @return array of exclusions as activity-user pairs
 */
function block_moodle_test_exclusions ($courseid, $userid = null) {
    global $DB;

    $query = "SELECT g.id, ". $DB->sql_concat('i.itemmodule', "'-'", 'i.iteminstance', "'-'", 'g.userid') ." as exclusion
               FROM {grade_grades} g, {grade_items} i
              WHERE i.courseid = :courseid
                AND i.id = g.itemid
                AND g.excluded <> 0";

    $params = array('courseid' => $courseid);
    if (!is_null($userid)) {
        $query .= " AND g.userid = :userid";
        $params['userid'] = $userid;
    }
    $results = $DB->get_records_sql($query, $params);
    $exclusions = array();
    foreach ($results as $value) {
        $exclusions[] = $value->exclusion;
    }
    return $exclusions;
}

/**
 * Determines whether a user is a member of a given group or grouping
 *
 * @param string $group    The group or grouping identifier starting with 'group-' or 'grouping-'
 * @param int    $courseid The ID of the course containing the block instance
 * @param int    $userid   The ID of the user
 * @return boolean value indicating membership
 */
function block_moodle_test_group_membership ($group, $courseid, $userid) {
    if ($group === '0') {
        return true;
    } else if ((substr($group, 0, 6) == 'group-') && ($groupid = intval(substr($group, 6)))) {
        return groups_is_member($groupid, $userid);
    } else if ((substr($group, 0, 9) == 'grouping-') && ($groupingid = intval(substr($group, 9)))) {
        return array_key_exists($groupingid, groups_get_user_groups($courseid, $userid));
    }

    return false;
}
