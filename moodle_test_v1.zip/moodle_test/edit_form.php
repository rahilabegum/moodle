<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * Test Moodle block configuration form definition
 *
 * @package    block_moodle_test
 * @copyright  2022
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot.'/blocks/moodle_test/lib.php');

/**
 * Test Moodle block config form class
 *
 * @copyright 2016 Michael de Raadt
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_moodle_test_edit_form extends block_edit_form {
    /**
     * Settings specific to this block.
     *
     * @param moodleform $mform
     */
    protected function specific_definition($mform) {
        global $COURSE, $OUTPUT;
        $activities = block_moodle_test_get_activities($COURSE->id, null, 'orderbycourse');
        $numactivies = count($activities);

        // The My home version is not configurable.
        if (block_moodle_test_on_site_page()) {
            return;
        }


        // Check that there are activities to monitor.
        if (empty($activities)) {
            $warningstring = get_string('no_activities_config_message', 'block_moodle_test');
            $activitieswarning = html_writer::tag('div', $warningstring, array('class' => 'warning'));
            $mform->addElement('static', '', '', $activitieswarning);
        }
    }
}
