<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Moodle Test block English language translation
 *
 * @package    block_moodle_test
 * @copyright  2022 Moodle User
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['pluginname'] = 'Moodle test';
$string['completion_not_enabled'] = 'Completion tracking is not enabled on this site.';
$string['completion_not_enabled_course'] = 'Completion tracking is not enabled in this course.';
$string['moodle_test:addinstance'] = 'Add a new Moodle Test block';
$string['moodle_test:myaddinstance'] = 'Add a Moodle Test block to My home page';
$string['coursenametoshow'] = 'Course name to show on Dashboard';
$string['no_activities_config_message'] = 'There are no activities or resources with activity completion set or no activities or resources have been selected. Set activity completion on activities and resources then configure this block.';
$string['no_blocks'] = 'No Moodle Test blocks are set up for your courses.';
$string['no_courses'] = "You are not enrolled in any courses. Only bars from enrolled courses will be shown.";