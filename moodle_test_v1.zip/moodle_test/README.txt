The Moodle Test block is show the list of activities and status of completion for students.
The block shows activities with activity completion settings.

To Install
1. Copy the moodle_test directory to the blocks/ directory of your Moodle instance
2. Visit the notifications page



Once the Moodle Test block is installed, you can use it in a course as follows.

1. Turn editing on
2. Create your activities/resources as normal
3. Set completion settings for each activity you want to appear in the block, including an created date
4. Add the Moodle Test block to your page
5. Move your block into a prominent position
6. (Optional) Configure how the block should appear

Hidden items will not appear in the Moodle Test block until they are visible to students.

